<?php

$arModuleVersion =
[
    'VERSION' => '1.0.0',
    'VERSION_DATE' => '2020.01.01 20:47:00'
];