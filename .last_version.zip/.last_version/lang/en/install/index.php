<?php

require_once __DIR__ .'/../../../helper.php';
$LOC = bx_loc_prefix();

$MESS[$LOC . 'MODULE_NAME'] = 'Google ReCaptcha';
$MESS[$LOC . 'MODULE_DESC'] = 'Google ReCaptcha v3.' . PHP_EOL . 'Spam protection.';
$MESS[$LOC . 'PARTNER_NAME'] = 'b01110011';
$MESS[$LOC . 'PARTNER_URI'] = 'https://github.com/b01110011/';

$MESS[$LOC . 'INSTALL_ERROR_VERSION'] = 'Installation error. D7 kernel version required';
$MESS[$LOC . 'INSTALL_TITLE'] = 'Install Google ReCaptcha';
$MESS[$LOC . 'UNINSTALL_TITLE'] = 'Delete Google ReCaptcha';