<?php

use B01110011ReCaptcha\Module as M;

$MESS[M::locPrefix() .'MODULE_NAME'] = 'Google ReCaptcha';
$MESS[M::locPrefix() .'MODULE_DESC'] = 'Google ReCaptcha v3.' . PHP_EOL . 'Spam protection.';
$MESS[M::locPrefix() .'PARTNER_NAME'] = 'b01110011';
$MESS[M::locPrefix() .'PARTNER_URI'] = 'https://github.com/b01110011/';

$MESS[M::locPrefix() .'INSTALL_ERROR_VERSION'] = 'Installation error. D7 kernel version required';
$MESS[M::locPrefix() .'INSTALL_TITLE'] = 'Install Google ReCaptcha';
$MESS[M::locPrefix() .'UNINSTALL_TITLE'] = 'Delete Google ReCaptcha';