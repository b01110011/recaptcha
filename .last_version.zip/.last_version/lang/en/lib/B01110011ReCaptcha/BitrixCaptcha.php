<?php

use B01110011ReCaptcha\Module as M;

$MESS[M::locPrefix() .'CAPTCHA_ERROR_MESSAGE'] = 'Your actions seem suspicious to us. Try reloading the page and re-filling the form.';