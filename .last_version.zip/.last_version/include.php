<?php

require_once __DIR__ .'/lib/autoload.php';