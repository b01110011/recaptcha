<?php

use B01110011ReCaptcha\Module as M;

$MESS[M::locPrefix() .'HEADER_BASE_SETTINGS'] = 'Base settings';
$MESS[M::locPrefix() .'HEADER_REGISTRATION'] = 'Registration';
$MESS[M::locPrefix() .'HEADER_WEBFORM_IDS'] = 'Web Form';
$MESS[M::locPrefix() .'HEADER_IBLOCK'] = 'Info Blocks';

$MESS[M::locPrefix() .'FIELD_SITE_KEY'] = 'Site key';
$MESS[M::locPrefix() .'FIELD_SECRET_KEY'] = 'Secret key';
$MESS[M::locPrefix() .'FIELD_PERMISSIBLE_SCORE'] = 'Permissible score';
$MESS[M::locPrefix() .'FIELD_HIDE_BADGE'] = 'Hide badge';
$MESS[M::locPrefix() .'FIELD_WEBFORM_IDS'] = 'Web Form ID';
$MESS[M::locPrefix() .'FIELD_REGISTRATION'] = 'Enable captcha';
$MESS[M::locPrefix() .'FIELD_ERROR_MESSAGE'] = 'Captcha error message';
$MESS[M::locPrefix() .'FIELD_IBLOCK_IDS'] = 'IBlock ID';