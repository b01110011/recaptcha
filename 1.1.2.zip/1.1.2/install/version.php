<?php

// должны быть " кавычки
$arModuleVersion =
[
    "VERSION" => "1.1.2",
    "VERSION_DATE" => "2020-03-04 14:30:00"
];