<?php

// должны быть " кавычки
$arModuleVersion =
[
    "VERSION" => "1.1.1",
    "VERSION_DATE" => "2020.03.03 14:00:00"
];