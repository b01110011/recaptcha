<?php

// должны быть " кавычки
$arModuleVersion =
[
    "VERSION" => "1.1.5",
    "VERSION_DATE" => "2020-03-28 18:24:00"
];