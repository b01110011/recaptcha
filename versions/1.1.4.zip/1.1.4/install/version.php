<?php

// должны быть " кавычки
$arModuleVersion =
[
    "VERSION" => "1.1.4",
    "VERSION_DATE" => "2020-03-27 19:54:00"
];