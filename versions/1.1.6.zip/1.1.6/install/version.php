<?php

// должны быть " кавычки
$arModuleVersion =
[
    "VERSION" => "1.1.6",
    "VERSION_DATE" => "2020-03-29 18:14:00"
];