<?php

// должны быть " кавычки
$arModuleVersion =
[
    "VERSION" => "1.1.0",
    "VERSION_DATE" => "2020.02.22 12:30:00"
];