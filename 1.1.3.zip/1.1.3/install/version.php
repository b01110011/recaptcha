<?php

// должны быть " кавычки
$arModuleVersion =
[
    "VERSION" => "1.1.3",
    "VERSION_DATE" => "2020-03-06 14:30:00"
];